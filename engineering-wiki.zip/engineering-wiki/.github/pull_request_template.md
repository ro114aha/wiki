## What changed
<!-- Short summary of the pages you added or edited -->

## Checklist
- [ ] Ran `mkdocs serve` and checked the pages render
- [ ] New pages are added to `nav` in `mkdocs.yml`
- [ ] Links are relative and end in `.md`
- [ ] Images are in `docs/assets/`
