# Engineering Wiki

Welcome. This wiki is plain Markdown stored in a Git repository. You can read it in two ways:

- **In GitHub:** browse the `docs/` folder. GitHub renders every page, including tables and diagrams.
- **As a website:** GitHub Pages publishes the same files as a searchable site with navigation.

Both views come from the same files, so there is only ever one copy to maintain.

## Start here

| If you want to… | Read |
|---|---|
| Understand how the wiki is organised | [Repo structure](getting-started/repo-structure.md) |
| Write or format a page | [Writing pages](getting-started/writing-pages.md) |
| Add a diagram | [Diagrams with Mermaid](getting-started/diagrams.md) |
| Propose a change | [How to contribute](getting-started/contributing.md) |
| Move content from Azure DevOps | [From Azure DevOps wiki](migration/from-azure-devops.md) |
| Understand the published site | [GitHub Pages](publishing/github-pages.md) |

## How a change flows

```mermaid
flowchart LR
    A[Edit Markdown] --> B[Open pull request]
    B --> C{Build check + review}
    C -->|approved| D[Merge to main]
    D --> E[GitHub Actions builds site]
    E --> F[Published to GitHub Pages]
```
