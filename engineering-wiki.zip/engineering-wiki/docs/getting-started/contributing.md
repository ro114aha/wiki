# How to contribute

Every change goes through a pull request, the same as code.

## Quick edits in the browser

1. Open the page on the site and click the **pencil (edit) icon**, or open the file on GitHub.
2. Make your change in the GitHub editor.
3. Choose **Create a new branch and start a pull request**.

For bigger edits across several pages, press **`.`** on the repo page to open the web editor (github.dev).

## Local edits with preview

```bash
git clone https://github.com/ORG/engineering-wiki.git
cd engineering-wiki
pip install -r requirements.txt
mkdocs serve                # preview at http://127.0.0.1:8000
git checkout -b docs/my-change
# edit files, then:
git commit -am "Docs: explain release rollback"
git push -u origin docs/my-change
```

## What happens on the pull request

- **Build check:** GitHub Actions runs `mkdocs build --strict`. It fails on broken internal links or pages missing from navigation.
- **Review:** `CODEOWNERS` automatically requests a review from the docs team.
- **Publish:** after merge to `main`, the site redeploys in a minute or two.

## Adding a new page

1. Create the `.md` file in the right section folder.
2. Add it to the `nav:` list in `mkdocs.yml`.
3. Link to it from at least one existing page.
