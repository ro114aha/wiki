# Repo structure

## Why Markdown in a repo

Storing the wiki as Markdown in a normal repository (instead of GitHub's built-in Wiki tab) gives you:

- **Pull request reviews** on every change, enforced with `CODEOWNERS` and branch protection.
- **Full history and blame** for every line.
- **Docs next to code** when you keep them in the same repo, so a feature and its docs ship together.
- **Search** through GitHub code search, and context for Copilot.
- **Portability**: it's just files, so you can move or publish them anywhere.

## Two places docs can live

| Option | Use it for | Example |
|---|---|---|
| `docs/` folder inside a code repo | Docs about that codebase: setup, architecture, APIs | `org/payments-api/docs/` |
| A dedicated docs repo | Team-wide knowledge: runbooks, onboarding, processes | `org/engineering-wiki` (this repo) |

Many teams use both: product docs live with the code, and a central wiki links to them.

## Folder layout

```
docs/
├── index.md              # home page (required by the site)
├── getting-started/      # one folder per section
│   └── repo-structure.md
├── migration/
├── publishing/
└── assets/               # images and attachments
```

## Naming conventions

- Use **lowercase with hyphens**: `release-process.md`, not `Release Process.md`.
- One topic per page; split pages longer than a few screens.
- Every folder that appears in navigation needs at least one page.
- Put images in `docs/assets/`, optionally in a subfolder per section.
- Page order is set in the `nav:` list in `mkdocs.yml` (this replaces Azure DevOps `.order` files).
