# Diagrams with Mermaid

[Mermaid](https://mermaid.js.org/) turns short text descriptions into diagrams. Because a diagram is just text inside a Markdown file, it is reviewed in pull requests, versioned in Git and never goes stale as a lost image file.

## Where Mermaid renders

| Place | Renders? | Notes |
|---|---|---|
| GitHub UI (files, pull requests, issues) | Yes | Built in, nothing to configure |
| GitHub Pages site (this wiki) | Yes | Enabled through `pymdownx.superfences` in `mkdocs.yml` |
| Azure DevOps wiki | Yes | Uses `::: mermaid` … `:::`, which must be converted |

## How to add a diagram

Use a fenced code block with the language set to `mermaid`:

````markdown
```mermaid
flowchart LR
    A[Edit] --> B[Pull request] --> C[Publish]
```
````

## Example: our migration and publishing flow

```mermaid
flowchart TD
    subgraph ADO["Azure DevOps"]
        A["Project wiki<br/>PROJECT.wiki repo"]
        B["Code wiki<br/>folder in a code repo"]
    end

    A -->|"git clone + import<br/>(keeps history)"| C
    B -->|"moves with repo<br/>(GitHub Enterprise Importer)"| C

    C["Clean up markdown<br/>.order → nav, fix links,<br/>convert mermaid blocks"]

    C --> D["GitHub repo<br/>docs/ folder"]

    D --> E["Pull request"]
    E --> F{"Checks"}
    F -->|"mkdocs build --strict"| G["Broken links caught"]
    F -->|"CODEOWNERS"| H["Docs team review"]
    G --> I["Merge to main"]
    H --> I

    I --> J["GitHub Actions<br/>builds site"]
    J --> K["GitHub Pages<br/>search, nav, dark mode"]

    D -.->|"browse directly"| L(["Readers"])
    K -.->|"browse as website"| L
```

## Example: what happens when you open a pull request

```mermaid
sequenceDiagram
    actor Author
    participant GH as GitHub
    participant CI as GitHub Actions
    actor Reviewer
    participant Pages as GitHub Pages

    Author->>GH: Push branch, open pull request
    GH->>CI: Run build check
    CI-->>GH: mkdocs build --strict passes
    GH->>Reviewer: Review requested (CODEOWNERS)
    Reviewer-->>GH: Approve
    Author->>GH: Merge to main
    GH->>CI: Run publish workflow
    CI->>Pages: Deploy site
    Pages-->>Author: Live in 1–2 minutes
```

## Example: a migration plan

```mermaid
gantt
    title Wiki migration plan
    dateFormat YYYY-MM-DD
    section Prepare
    Inventory ADO wikis        :a1, 2026-10-12, 3d
    Create GitHub docs repo    :a2, after a1, 1d
    section Migrate
    Import content + history   :b1, after a2, 2d
    Clean up links and syntax  :b2, after b1, 5d
    section Launch
    Enable GitHub Pages        :c1, after b2, 1d
    ADO wiki read-only         :c2, after c1, 1d
```

## Useful diagram types

| Type | Keyword | Good for |
|---|---|---|
| Flowchart | `flowchart TD` / `flowchart LR` | Processes, decisions, architecture overviews |
| Sequence | `sequenceDiagram` | Requests between services, approval flows |
| Gantt | `gantt` | Project plans and timelines |
| State | `stateDiagram-v2` | Ticket or deployment lifecycles |
| Entity relationship | `erDiagram` | Database schemas |
| Git graph | `gitGraph` | Branching strategies |

## Tips

- **Use `TD` (top-down) for long flows.** It reads better on phones and narrow screens than `LR`.
- **Quote labels with special characters:** `A["Build (strict)"]`.
- **Use `<br/>` for line breaks** inside labels.
- **Keep diagrams small.** Split anything over about 15 boxes into two diagrams.
- **Draft in the [Mermaid Live Editor](https://mermaid.live/)**, then paste the code into the page.
- **Preview locally** with `mkdocs serve` before opening a pull request.
