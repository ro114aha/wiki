# Writing pages

Write standard GitHub-flavoured Markdown. Pages should read well both in the GitHub UI and on the published site.

## Page basics

- Start every page with a single `#` heading. It becomes the page title.
- Use `##` and `###` for sections. The site builds the "On this page" outline from them.
- Keep paragraphs short; tables and lists scan better than long prose.

## Links

Use **relative links that include `.md`**. They work in GitHub and on the site:

```markdown
See [How to contribute](contributing.md).
See [GitHub Pages](../publishing/github-pages.md#what-pages-adds).
```

Avoid absolute site URLs for internal links; they break in the GitHub view and in local previews.

## Images

```markdown
![Deployment pipeline](../assets/pipeline.png)
```

## Diagrams

Mermaid renders natively in GitHub and on the site:

````markdown
```mermaid
flowchart LR
    Dev --> PR --> Review --> Main
```
````

For more diagram types and examples, see [Diagrams with Mermaid](diagrams.md).

## Tables and code

````markdown
| Env | URL |
|---|---|
| Staging | https://staging.example.com |

```bash
mkdocs serve
```
````

## Callouts (site only)

The published site supports admonitions:

```markdown
!!! warning "Production access"
    Request access through the access portal before your on-call shift.
```

These show as plain indented text in the GitHub UI, so use them where the site is the main reading view.

## Things that don't carry over from Azure DevOps

| Azure DevOps | Use instead |
|---|---|
| `[[_TOC_]]` | Remove it; the outline is automatic |
| `::: mermaid` … `:::` | A ` ```mermaid ` fenced block |
| `#1234` work item links | A full link to the issue or work item |
| `@mentions` | The person's or team's GitHub handle in plain text |
