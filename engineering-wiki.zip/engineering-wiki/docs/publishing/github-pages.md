# GitHub Pages

The Markdown in this repo is already readable on GitHub. GitHub Pages turns the same files into a proper documentation website. Nothing is copied or duplicated: a GitHub Actions workflow builds the site from `docs/` on every merge.

## What Pages adds

| Feature | What readers get |
|---|---|
| **Navigation** | Top tabs per section, a grouped sidebar, and previous/next links at the bottom of each page |
| **Full-text search** | Instant search across every page with suggestions and highlighted matches |
| **Page outline** | An "On this page" panel that follows you as you scroll |
| **Edit this page** | A pencil icon that opens the file on GitHub, ready for a pull request |
| **Last updated** | Each page shows when it was created and last changed, taken from Git history |
| **Dark mode** | Follows the reader's system setting, with a toggle |
| **Readable content** | Copy buttons on code blocks, rendered Mermaid diagrams, callout boxes, tabbed sections |
| **Fast loading** | Pages switch instantly without a full reload |
| **Stable links** | Every heading gets a permalink you can share |

Compared with browsing folders in the GitHub UI, the site feels like a wiki: you navigate by topic rather than by file path, and search covers only the docs.

## Access control

- **GitHub Enterprise Cloud:** set the Pages site visibility to **private** so only organisation members can read it.
- **GitHub Enterprise Server:** a site admin must enable Pages for the instance. Check with your admin whether sites are public or restricted to signed-in users.

## One-time setup

1. In the repo, go to **Settings → Pages**.
2. Under **Build and deployment → Source**, choose **GitHub Actions**.
3. (Cloud only) Set visibility to **Private**.
4. Merge any change to `docs/`. The `Publish wiki` workflow builds and deploys the site.
5. The site URL appears in **Settings → Pages** and on the workflow run.

## How the site is configured

All behaviour lives in `mkdocs.yml`:

- `nav:` sets page order and grouping.
- `theme.features:` turns on tabs, search suggestions, the edit button and code copy.
- `plugins:` adds search and "last updated" dates.
- `markdown_extensions:` enables Mermaid, callouts, tabs and heading permalinks.

The site uses [MkDocs](https://www.mkdocs.org/) 1.x with the Material theme. `requirements.txt` pins MkDocs below 2.0, because MkDocs 2.0 drops the plugin and theme systems this setup relies on. The Material team's recommended next step is Zensical, which reads the same `mkdocs.yml`. Review that before you standardise long term.

## Optional extras

- **Versioned docs** (one site per release) with the `mike` tool.
- **Custom domain**, e.g. `wiki.example.com`, under Settings → Pages.
- **Section ordering without editing `nav:`** using the `awesome-pages` plugin and per-folder `.pages` files.
