# Migrating from an Azure DevOps wiki

Azure DevOps wikis are Git repos of Markdown, so they move with their history intact. GitHub Enterprise Importer migrates code repos but not wikis, so this is a manual step.

## 1. Identify the wiki type

- **Project wiki**: stored in a hidden repo named `{Project}.wiki`, default branch `wikiMaster`.
- **Code wiki** (published from a repo folder): already in your code repo; it moves when the repo does.

## 2. Copy the content with history

```bash
git clone https://dev.azure.com/ORG/PROJECT/_git/PROJECT.wiki ado-wiki
git clone https://github.com/ORG/engineering-wiki.git
cd engineering-wiki

# Pull the ADO history into a docs/ subfolder
git remote add ado ../ado-wiki
git fetch ado
git merge -s ours --no-commit --allow-unrelated-histories ado/wikiMaster
git read-tree --prefix=docs/legacy/ -u ado/wikiMaster
git commit -m "Import Azure DevOps wiki with history"
```

If you don't need history, just copy the files into `docs/`.

## 3. Clean up

| Azure DevOps | GitHub repo + MkDocs |
|---|---|
| `.order` files | `nav:` in `mkdocs.yml` |
| `.attachments/` | `docs/assets/` (update image paths) |
| `Page-Name.md` with `%2D`, `%3A` encodings | Rename to plain lowercase-hyphen names |
| Links like `/Parent/Child-Page` | Relative links: `../parent/child-page.md` |
| `[[_TOC_]]` | Delete |
| `::: mermaid` blocks | ` ```mermaid ` fenced blocks |
| `#123` work items | Full URLs |

Run `mkdocs build --strict` after cleanup. It lists every broken link, which makes it a good checklist.

## 4. Switch over

- Make the Azure DevOps wiki read-only.
- Add a banner on its home page linking to the new site.
- Keep it for a few months, then archive it.
